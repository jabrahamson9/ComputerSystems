/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_129(unsigned *p)
{
    *p = 3281031256U;
}

unsigned getval_248()
{
    return 2428995912U;
}

unsigned addval_330(unsigned x)
{
    return x + 3351742792U;
}

void setval_303(unsigned *p)
{
    *p = 3351742792U;
}

unsigned getval_408()
{
    return 3347663042U;
}

unsigned addval_447(unsigned x)
{
    return x + 2425378883U;
}

unsigned addval_407(unsigned x)
{
    return x + 2425393752U;
}

void setval_294(unsigned *p)
{
    *p = 3281000470U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_264()
{
    return 3284240839U;
}

void setval_284(unsigned *p)
{
    *p = 3284830488U;
}

unsigned getval_262()
{
    return 3269495112U;
}

unsigned addval_227(unsigned x)
{
    return x + 3674789545U;
}

unsigned addval_219(unsigned x)
{
    return x + 3685013129U;
}

unsigned getval_458()
{
    return 3375945225U;
}

unsigned addval_102(unsigned x)
{
    return x + 3397919937U;
}

void setval_369(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_343()
{
    return 3225993609U;
}

void setval_243(unsigned *p)
{
    *p = 3224945032U;
}

void setval_468(unsigned *p)
{
    *p = 3682915977U;
}

unsigned getval_457()
{
    return 3676359305U;
}

unsigned getval_263()
{
    return 3224423049U;
}

unsigned addval_469(unsigned x)
{
    return x + 3223896457U;
}

void setval_492(unsigned *p)
{
    *p = 2428603648U;
}

unsigned getval_221()
{
    return 3375942153U;
}

unsigned addval_220(unsigned x)
{
    return x + 2497743176U;
}

void setval_236(unsigned *p)
{
    *p = 2428610816U;
}

void setval_295(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_277()
{
    return 3373845129U;
}

unsigned getval_278()
{
    return 3767091390U;
}

unsigned addval_499(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_473()
{
    return 3378566793U;
}

void setval_467(unsigned *p)
{
    *p = 3599468182U;
}

unsigned getval_314()
{
    return 2430634824U;
}

unsigned addval_223(unsigned x)
{
    return x + 3682915977U;
}

unsigned getval_383()
{
    return 2425473673U;
}

void setval_466(unsigned *p)
{
    *p = 3523791513U;
}

unsigned addval_183(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_256()
{
    return 2462157143U;
}

void setval_193(unsigned *p)
{
    *p = 3373848201U;
}

unsigned getval_147()
{
    return 3375939977U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
